"use client";

import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import type { Session } from "@supabase/supabase-js";
import LoginForm from "@/components/LoginForm";
import TaskInput from "@/components/TaskInput";
import ExecutionView from "@/components/ExecutionView";

const DEMO_MODE = !process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.NEXT_PUBLIC_DEMO_MODE === "true";

function getSupabase() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}

// Fake session for demo mode
const DEMO_SESSION = {
  access_token: "demo-token",
  user: { email: "demo@alloraai.com", id: "00000000-0000-0000-0000-000000000001" },
} as unknown as Session;

export default function Home() {
  const [session, setSession] = useState<Session | null | undefined>(undefined); // undefined = loading
  const [taskId, setTaskId] = useState<string | null>(null);

  useEffect(() => {
    if (DEMO_MODE) {
      setSession(DEMO_SESSION);
      return;
    }
    const supabase = getSupabase();
    // Get initial session
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (!session) setTaskId(null); // reset on logout
    });
    return () => subscription.unsubscribe();
  }, []);

  async function handleUserResponse(fields: Record<string, string>) {
    if (!taskId || !session) return;
    await fetch(`/api/task/${taskId}/respond`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({ task_id: taskId, fields }),
    });
  }

  async function handleConfirm(confirmed: boolean) {
    if (!taskId || !session) return;
    await fetch(`/api/task/${taskId}/confirm`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({ task_id: taskId, confirmed }),
    });
  }

  async function handleSignOut() {
    await getSupabase().auth.signOut();
  }

  // Loading
  if (session === undefined) {
    return (
      <div className="min-h-screen bg-zinc-50 flex items-center justify-center">
        <p className="text-sm text-zinc-400">Loading…</p>
      </div>
    );
  }

  // Not logged in
  if (!session) {
    return (
      <div className="min-h-screen bg-zinc-50 flex flex-col items-center justify-center px-4">
        <LoginForm onLogin={() => {}} />
      </div>
    );
  }

  // Logged in
  return (
    <div className="min-h-screen bg-zinc-50 flex flex-col items-center justify-start py-16 px-4">
      {/* Header */}
      <div className="w-full max-w-2xl flex justify-between items-center mb-8">
        <span className="text-xs text-zinc-400">{session.user.email}</span>
        <button
          onClick={handleSignOut}
          className="text-xs text-zinc-500 hover:text-zinc-800 underline"
        >
          Sign out
        </button>
      </div>

      {!taskId ? (
        <TaskInput onTaskCreated={setTaskId} />
      ) : (
        <>
          <ExecutionView
            task_id={taskId}
            token={session.access_token}
            onUserResponse={handleUserResponse}
            onConfirm={handleConfirm}
          />
          <button
            onClick={() => setTaskId(null)}
            className="mt-6 text-sm text-zinc-400 hover:text-zinc-700 underline"
          >
            ← New task
          </button>
        </>
      )}
    </div>
  );
}
