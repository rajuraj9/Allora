// ============================================================
// app/api/task/route.ts
// POST /api/task — create a new task and trigger the agent loop
// ============================================================

import { NextResponse } from "next/server";
import { validateJWT } from "@/lib/auth";
import { getSupabaseClient } from "@/lib/supabase";
import { runAgentLoop } from "@/lib/agent-loop";
import { isDemoMode, getDemoScenario } from "@/lib/demo-mode";
import { demoStore } from "@/lib/demo-store";

// ----------------------------------------------------------------
// 9.6 In-memory rate limiter: max 10 requests per minute per user
// ----------------------------------------------------------------

interface RateLimitEntry {
  count: number;
  windowStart: number;
}

const rateLimitMap = new Map<string, RateLimitEntry>();
const RATE_LIMIT_MAX = 10;
const RATE_LIMIT_WINDOW_MS = 60_000; // 1 minute

function checkRateLimit(user_id: string): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(user_id);
  if (!entry || now - entry.windowStart >= RATE_LIMIT_WINDOW_MS) {
    rateLimitMap.set(user_id, { count: 1, windowStart: now });
    return true;
  }
  if (entry.count >= RATE_LIMIT_MAX) return false;
  entry.count += 1;
  return true;
}

// ----------------------------------------------------------------
// POST /api/task
// ----------------------------------------------------------------

export async function POST(request: Request) {
  try {
    // Validate JWT
    const auth = await validateJWT(request);
    if (!auth) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { user_id } = auth;
    console.log("[POST /api/task] auth ok, user_id:", user_id);

    // Rate limiting
    if (!checkRateLimit(user_id)) {
      return NextResponse.json(
        { error: "Too many requests. Please wait before submitting another task." },
        { status: 429 }
      );
    }

    // Parse body
    let body: unknown;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
    }

    const goal =
      body && typeof body === "object" && "goal" in body
        ? (body as Record<string, unknown>).goal
        : undefined;

    if (!goal || typeof goal !== "string" || goal.trim() === "") {
      return NextResponse.json(
        { error: "goal must be a non-empty string" },
        { status: 400 }
      );
    }

    console.log("[POST /api/task] goal:", goal.trim());

    // Demo mode without Supabase: use in-memory store
    if (isDemoMode() && !process.env.NEXT_PUBLIC_SUPABASE_URL) {
      const task_id = crypto.randomUUID();
      demoStore.createTask(task_id, goal.trim());
      console.log("[POST /api/task] demo task created:", task_id);

      setImmediate(async () => {
        const scenario = getDemoScenario(goal.trim());
        demoStore.updateTask(task_id, { status: "running" });
        demoStore.upsertStep({
          id: crypto.randomUUID(), task_id, step_id: "step_1",
          action_type: "open", target: "Allora AI Demo",
          status: "running", result: null, retry_count: 0,
          timestamp: new Date().toISOString(),
        });
        for (const s of scenario.steps) {
          await new Promise((r) => setTimeout(r, s.delay));
          demoStore.updateStep(task_id, "step_1", {
            result: { success: true, extracted_data: { _progress: s.purpose }, page_state: { url: "", title: "", forms_detected: [] } },
          });
        }
        demoStore.updateStep(task_id, "step_1", {
          status: "success",
          result: { success: true, extracted_data: { ...scenario.result }, page_state: { url: "", title: "", forms_detected: [] } },
        });
        demoStore.updateTask(task_id, {
          status: "completed",
          result: { summary: scenario.summary, extracted_data: scenario.result, confirmation_log: [] },
        });
      });

      return NextResponse.json({ task_id, status: "pending" }, { status: 201 });
    }

    const db = getSupabaseClient();

    // Create TaskRecord
    const { data: task, error: insertError } = await db
      .from("tasks")
      .insert({
        user_id,
        goal: goal.trim(),
        status: "pending",
        step_plan: [],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select("id")
      .single();

    if (insertError || !task) {
      console.error("[POST /api/task] Supabase insert error:", {
        message: insertError?.message,
        code: insertError?.code,
        details: insertError?.details,
        hint: insertError?.hint,
        user_id,
      });
      return NextResponse.json(
        { error: "Failed to create task", detail: insertError?.message },
        { status: 500 }
      );
    }

    const task_id: string = task.id;
    console.log("[POST /api/task] task created:", task_id);

    // Fire-and-forget agent loop
    if (isDemoMode()) {
      // Demo mode: simulate agent execution with realistic delays
      setImmediate(async () => {
        const scenario = getDemoScenario(goal.trim());
        const db = getSupabaseClient();

        await db.from("tasks").update({ status: "running", updated_at: new Date().toISOString() }).eq("id", task_id);

        const step: { step_id: string; action_type: string; target: string; status: string; result: null; retry_count: number; timestamp: string; task_id: string } = {
          task_id,
          step_id: "step_1",
          action_type: "open",
          target: "Allora AI Demo",
          status: "running",
          result: null,
          retry_count: 0,
          timestamp: new Date().toISOString(),
        };
        await db.from("step_logs").insert(step);

        for (const s of scenario.steps) {
          await new Promise((r) => setTimeout(r, s.delay));
          await db.from("step_logs")
            .update({ result: { success: true, extracted_data: { _progress: s.purpose }, page_state: { url: "", title: "", forms_detected: [] } } })
            .eq("task_id", task_id).eq("step_id", "step_1");
        }

        await db.from("step_logs")
          .update({ status: "success", result: { success: true, extracted_data: { ...scenario.result }, page_state: { url: "", title: "", forms_detected: [] } } })
          .eq("task_id", task_id).eq("step_id", "step_1");

        await db.from("tasks").update({
          status: "completed",
          result: { summary: scenario.summary, extracted_data: scenario.result, confirmation_log: [] },
          updated_at: new Date().toISOString(),
        }).eq("id", task_id);
      });
    } else {
      setImmediate(() => {
        runAgentLoop({ task_id, goal: goal.trim(), user_id }).catch(async (err) => {
          console.error("[agent-loop] unhandled error:", err);
          try {
            await db
              .from("tasks")
              .update({
                status: "failed",
                failure_reason: err instanceof Error ? err.message : String(err),
                updated_at: new Date().toISOString(),
              })
              .eq("id", task_id);
          } catch (dbErr) {
            console.error("[agent-loop] failed to update task status after error:", dbErr);
          }
        });
      });
    }

    return NextResponse.json({ task_id, status: "pending" }, { status: 201 });

  } catch (err) {
    console.error("[POST /api/task] unexpected error:", err);
    return NextResponse.json(
      { error: "Internal server error", detail: String(err) },
      { status: 500 }
    );
  }
}
